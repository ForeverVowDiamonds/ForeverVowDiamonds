
console.log('Forever Vow Diamonds site loaded');
